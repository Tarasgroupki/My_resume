<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=my_skill',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];

