$('.four').on('click',function(){
	$('.navbar-collapse').toggle('js');
	});