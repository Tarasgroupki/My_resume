<code><?=__FILE__?></code>
<?php
debug($posts);
//var_dump($posts);