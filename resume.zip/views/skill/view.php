<div class="view_title"><h1><?=$skill['title'];?></h1></div>
<div class="view_desc"><?=$skill['description'];?></div>