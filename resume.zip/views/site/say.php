<?php
use yii\helpers\Html;
?>
<?= Html::encode($message) ?>